// @flow strict
export { default } from './Icon';
