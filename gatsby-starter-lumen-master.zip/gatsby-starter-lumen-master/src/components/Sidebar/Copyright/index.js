// @flow strict
export { default } from './Copyright';
