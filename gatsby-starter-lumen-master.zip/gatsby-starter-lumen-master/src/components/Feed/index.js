// @flow strict
export { default } from './Feed';
