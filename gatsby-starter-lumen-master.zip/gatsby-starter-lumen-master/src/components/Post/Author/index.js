// @flow strict
export { default } from './Author';
