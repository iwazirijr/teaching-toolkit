// @flow strict
export { default } from './Tags';
