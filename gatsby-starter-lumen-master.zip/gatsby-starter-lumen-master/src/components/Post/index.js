// @flow strict
export { default } from './Post';
