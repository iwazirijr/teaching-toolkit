// @flow strict
export { default } from './Comments';
