// @flow strict
export { default } from './Content';
