// @flow strict
export { default } from './Meta';
