// @flow strict
const PAGINATION = {
  PREV_PAGE: '← PREV',
  NEXT_PAGE: '→ NEXT'
};

export default PAGINATION;
