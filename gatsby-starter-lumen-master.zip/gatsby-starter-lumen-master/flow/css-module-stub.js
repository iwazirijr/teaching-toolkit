// @flow strict
type CSSModule = {
  [key: string]: string,
};

const emptyCSSModule: CSSModule = {};

export default emptyCSSModule;
