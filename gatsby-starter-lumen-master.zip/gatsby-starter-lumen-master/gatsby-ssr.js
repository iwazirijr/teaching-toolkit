'use strict';

exports.onRenderBody = require('./gatsby/on-render-body.js');
