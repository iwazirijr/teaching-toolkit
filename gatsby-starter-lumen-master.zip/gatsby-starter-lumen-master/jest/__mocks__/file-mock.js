'use strict';

module.exports = 'file';
