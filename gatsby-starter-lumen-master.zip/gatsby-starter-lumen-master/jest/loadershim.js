'use strict';

global.___loader = {
  enqueue: jest.fn(),
};
