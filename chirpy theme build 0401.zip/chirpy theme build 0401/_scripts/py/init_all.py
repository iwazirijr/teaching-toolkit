#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Automatic invokes all initial scripts for project.
v2.0
https://github.com/iwazirijr/iwazirijr.github.io
© 2018-2019 Ibrahim Waziri Jr.
Licensed under MIT
"""

import update_posts_lastmod
import pages_generator


update_posts_lastmod

pages_generator
