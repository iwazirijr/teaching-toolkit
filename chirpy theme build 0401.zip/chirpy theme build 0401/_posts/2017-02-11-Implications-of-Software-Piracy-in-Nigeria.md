---
title: Implications of Software Piracy in Nigeria
date: 2017-02-11 20:55:00 +0800
categories: [Africa, Software Piracy]
tags: [Software Piracy, Africa]
toc: false
---

As our lives depend more and more on software usage, ensuring that the software we use is secured is essential. The rate of software piracy in Africa keeps rising. There is at least one pirated software installed in one out of every five devices in Africa. As these devices continuously connect to the internet, they expand the attack surfaces of African networks. 

The software piracy rate in developing nations like Nigeria is at 83 percent and that of Zimbabwe at 92 percent (ChartsBin '09). These high rates are as a result of the high cost of the software licenses. The subscription cost of one of the most globally used software, Office 365 is \$99/year, and Office Home Suite at ​\$149.99.  That is the cost of a brand new low-end laptop. One can understand why most end-users in developing nations use pirated software. 

Beyond the legal implications of using pirated software (which the FBI APW seal is meant to mitigate), exist technical risks like using compromised software injected with malware. An example is the Remote Access Trojan (RAT). RAT malware acts as a backdoor in software, giving an attacker remote access to the malware-infected device or network. To most end users, using pirated software is worth the risk. However, when the same end-users connect their devices to organization/government networks - it becomes a much bigger issue (or even a national security threat - such as IRAN's Stuxnet). 

Let us take a scenario with a bank employee as an example; what happens when an employee decides to torrent a software using the bank's internal network because it is faster than the free wifi provided by the bank? Now imagine, the torrented software is infected with RAT, which gives an attacker access to the bank's internal network. A more devastating scenario could be that the same software is infected with keylogger malware allowing an attacker to record every single keyboard stroke the employee makes. Such an incident does not give the attacker access to the bank's internal network, but also, the attacker can access customer funds by posing as the bank employee. (The technicalities behind implementing this type of attack are not that easy, but it is possible.)

Pirated software lacks vendor integrity; hence, the software consumer is unaware of any changes to the source code, nor the software vendor tracking any changes as well. As such, it is often difficult to patch/update a pirated software. So to the attacker, it will forever be a zero-day exploit. Additionally, Responsible Disclosure and Vulnerability Disclosure Policies do not apply to pirated software. 

As Ken Thompson wrote in his 1984 Turing Award Lecture paper titled 'Reflections on Trusting Trust'; 'A user can only trust software to act as designed to if they wrote every piece of the software code." So, when end-users use a verified genuine software (with a verified checksum). The end-users are not trusting the software to be free of security vulnerabilities, but rather, they are trusting the software has undergone an approved vulnerability assessment either by the vendor or whoever is responsible for distributing the software.

Most institutions have security measures, controls, and policies to circumvent these types of security issues. Also (depending on institution type and jurisdictions), there are requirements to comply with specific regulations (including security controls). But the truth is that these measures, controls, and policies are limited and undermined, especially within developing nations like Nigeria. This limited capacity makes combating software piracy in Nigeria a priority when it comes to ensuring safer cyberspace in Nigeria. 

In the next writing, we are going to discuss what approaches Nigeria can take to minimize the rate of software piracy.

