/**
 * Initial Bootstrap Tooltip.
 * v2.0
 * https://github.com/iwazirijr/iwazirijr.github.io
 * © 2019 Ibrahim Waziri Jr.
 * MIT License
*/
$(function () {
  $('[data-toggle="tooltip"]').tooltip();
})