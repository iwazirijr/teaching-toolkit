---
title: About

# The About me page
# v2.0
# https://github.com/iwazirijr/iwazirijr.github.io
# © 2020 Ibrahim Waziri Jr.
# MIT License
---

> **Note**: Add Markdown syntax content to file `tabs/about.md` and it will show up on this page.